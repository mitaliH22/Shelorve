import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-framework',
  templateUrl: './edit-framework.component.html',
  styleUrls: ['./edit-framework.component.css']
})
export class EditFrameworkComponent {

}
