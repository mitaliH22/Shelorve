import { Component } from '@angular/core';

@Component({
  selector: 'app-upload-framework',
  templateUrl: './upload-framework.component.html',
  styleUrls: ['./upload-framework.component.css']
})
export class UploadFrameworkComponent {

}
